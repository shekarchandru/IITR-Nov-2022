package com.greatlearningServiceImplements;

import com.greatlearningService.ExamTip;
import com.greatlearningService.Teacher;

public class GkTeacher implements Teacher {
//  defining a private field for dependency
	ExamTip examTip;
    public GkTeacher() {
    	
    }
	// defining constructor for dependency injection
	public GkTeacher(ExamTip theexamTip) {
		examTip = theexamTip;
	}
	@Override
	public String getHomework() {
		// TODO Auto-generated method stub
		return "update current affairs";
	}
	@Override
	public String getExamTip() {
		return examTip.getExamTip();
	}

}
