package com.greatlearningServiceImplements;

import com.greatlearningService.ExamTip;

public class RevisionTip implements ExamTip {

	@Override
	public String getExamTip() {
		// TODO Auto-generated method stub
		return "do revison";
	}

}
