package com.greatlearningServiceImplements;

import com.greatlearningService.ExamTip;
import com.greatlearningService.Teacher;

public class HindiTeacher implements Teacher {
	// defining a private field for dependency
	ExamTip examTip;

	public HindiTeacher() {

	}

	public HindiTeacher(ExamTip theexamTip) {
		examTip = theexamTip;
	}
	@Override
	public String getHomework() {
		// TODO Auto-generated method stub
		return " complete essay";
	}
	@Override
	public String getExamTip() {
		return examTip.getExamTip();
	}
}
