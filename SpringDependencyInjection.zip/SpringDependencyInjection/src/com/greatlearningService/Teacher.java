package com.greatlearningService;

public interface Teacher extends ExamTip {
	public String getHomework();
	 public String getExamTip();
}
