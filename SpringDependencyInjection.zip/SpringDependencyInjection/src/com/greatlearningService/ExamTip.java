package com.greatlearningService;

public interface ExamTip {
 public String getExamTip();
}
