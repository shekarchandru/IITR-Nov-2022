package com.gl.ticket.TicketTracker.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.ticket.TicketTracker.model.Student;



public interface StudentDao extends JpaRepository<Student, Integer> {
}
