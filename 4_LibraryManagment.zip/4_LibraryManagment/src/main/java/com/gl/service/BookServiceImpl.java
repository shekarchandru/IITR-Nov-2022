package com.gl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gl.dao.BookRepository;
import com.gl.entity.Book;

@Service
public class BookServiceImpl implements BookService{

	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public List<Book> findAll() {
		return bookRepository.findAll();
	}

	@Override
	public void save(Book theBook) {
		bookRepository.save(theBook);
	}

	@Override
	public void deleteById(int id) {
		bookRepository.deleteById(id);
	}

	@Override
	public Book findById(int id) {
		Book book = bookRepository.findById(id).get();
		
		if(book == null)
			throw new RuntimeException("Did not find the book id: " + id);
		else
			return book;
			
	}

}
