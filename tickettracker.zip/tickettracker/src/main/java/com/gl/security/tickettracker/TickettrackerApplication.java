package com.gl.security.tickettracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TickettrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TickettrackerApplication.class, args);
		System.out.println("\n\nWelcome to the Ticket Tracker Application");
		System.out.println("\nHit localhost:<PORT> on your Web-Browser");
	
	}

}
