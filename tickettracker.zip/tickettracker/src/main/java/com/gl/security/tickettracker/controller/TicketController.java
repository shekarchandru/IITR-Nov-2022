package com.gl.security.tickettracker.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.gl.security.tickettracker.entity.Ticket;
import com.gl.security.tickettracker.service.TicketService;



@Controller
@RequestMapping("/admin/tickets")
public class TicketController {

	// Refer to http://localhost/<PORT>/swagger-ui.html - for the API Documentation

	// GET - /admin/tickets - listTickets
	// POST - /admin/tickets/delete - deleteTicket
	// POST - /admin/tickets/edit/{id} - updateTicket
	// GET - /admin/tickets/newTicket - createTicket
	// POST - /admin/tickets/save - saveTicket
	// GET - /admin/tickets/search - searchTickets
	// POST - /admin/tickets/update/{id} - updateTicket
	// POST - /admin/tickets/view/{id} - viewTicket

	@Autowired
	private TicketService ticketService;

	// SEARCH a ticket by its 'title' and 'description'
	@GetMapping("/search")
	public String searchTickets(@RequestParam("query") String query, Model model) {

		if (query.trim().isEmpty())
			return "redirect:/admin/tickets";

		List<Ticket> searchedTickets = ticketService.searchTickets(query);
		//List<Ticket> searchedTicketsWithoutTimestamp = ticketService.removeTimestamp(searchedTickets);
	//	model.addAttribute("tickets", searchedTicketsWithoutTimestamp);
		model.addAttribute("tickets", searchedTickets);
		return "tickets/list-tickets";
	}

	// Package the ticket object inside the Model
	@GetMapping("/newTicket")
	public String createticket(Model model) {

		Ticket ticket = new Ticket();
		model.addAttribute("ticket", ticket);
		return "tickets/ticket-form";
	}

	// READ (FETCH) all tickets
	@GetMapping("/list")
	public String listTickets(Model theModel) {

		System.out.println("you are here in list controller");
		List<Ticket> tickets = ticketService.viewAlltickets();
	//	List<Ticket> ticketsWithoutTimestamp = ticketService.removeTimestamp(tickets);
	//	theModel.addAttribute("tickets", ticketsWithoutTimestamp);
		theModel.addAttribute("tickets", tickets);
		System.out.println(tickets);
		//return "/tickets/hello";
		return "tickets/list-tickets";
	}

	// CREATE a ticket
	@GetMapping("/save")
	public String saveTicket(@ModelAttribute("ticket") Ticket ticket) {

		ticketService.saveTicket(ticket);
		return "redirect:/admin/tickets/list";
	}

	// UPDATE a ticket by altering its attribute ('title', 'description', 'content')
	//Changed Post to Put
	@PutMapping("/update/{id}")
	public String updateTicket(@PathVariable("id") long id, @ModelAttribute("ticket") Ticket ticket) {

		Ticket originalTicket = ticketService.viewticketById(id);
		ticket.setDateCreated(originalTicket.getDateCreated());
		ticketService.updateTicket(ticket);
		return "redirect:/admin/tickets/list";
	}

	// DELETE Tickets
	//Changed Post to Delete
	@DeleteMapping("/delete")
	public String deleteticket(@RequestParam("ticketId") long id) {

		ticketService.removeticketById(id);
		return "redirect:/admin/tickets/list";
	}

	// Unboxing the saved Ticket (Model) and Pre-Populating the form for UPDATE
	@GetMapping("/edit/{id}")
	public String updateTicket(@PathVariable("id") long id, Model model) {

		Ticket ticket = ticketService.viewticketById(id);
		model.addAttribute("ticket", ticket);
		return "tickets/update-ticket";
	}

	// VIEW a single ticket
	@GetMapping("/view/{id}")
	public String viewTicket(@PathVariable("id") long id, Model model) {

		Ticket ticket = ticketService.viewticketById(id);
		model.addAttribute("ticket", ticket);
		return "tickets/view-ticket";
	}
	
	@RequestMapping(value = "/403")
	public ModelAndView accesssDenied(Principal user) {

		ModelAndView model = new ModelAndView();

		if (user != null) {
			model.addObject("msg", "Hi " + user.getName() 
			+ ", you do not have permission to access this page!");
		} else {
			model.addObject("msg", 
			"You do not have permission to access this page!");
		}

		model.setViewName("403");
		return model;

	}

}
