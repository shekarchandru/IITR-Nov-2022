package com.gl.security.tickettracker.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class MyController {

	
	@RequestMapping("/greet")
	public String sayHello()
	{
		return "tickets/hello";
	}
}
