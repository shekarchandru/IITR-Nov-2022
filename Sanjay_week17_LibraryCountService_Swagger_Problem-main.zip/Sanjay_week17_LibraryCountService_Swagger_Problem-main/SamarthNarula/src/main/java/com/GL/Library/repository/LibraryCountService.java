package com.GL.Library.repository;

public interface LibraryCountService {

	long countLibraries();

	long countLibrariesWithNoBooks();

}