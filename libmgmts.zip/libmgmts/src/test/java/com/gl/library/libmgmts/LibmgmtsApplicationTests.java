package com.gl.library.libmgmts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibmgmtsApplicationTests {

	@Test
	void contextLoads() {
	}

}
