package com.gl.library.libmgmts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages= {"com.gl.library.libmgmts.*"})
public class LibmgmtsApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibmgmtsApplication.class, args);
	}

}
