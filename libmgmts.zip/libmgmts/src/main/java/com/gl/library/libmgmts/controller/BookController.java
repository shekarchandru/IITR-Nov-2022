package com.gl.library.libmgmts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gl.library.libmgmts.model.Book;
import com.gl.library.libmgmts.service.BookService;



@Controller
@RequestMapping("/books")
public class BookController {

	@Autowired
	BookService bookService;

	/*
	 * find out the resources URI for that we need to support /books/showFormForAdd
	 * --> Display the Form in which we have to fill the book object.
	 * /books/showFormForUpdate --> Update the book object /books/delete --> Delete
	 * the book object. /books/save --> Save Book Object /books/list --> Display all
	 * the Books.
	 */

	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel) {

		Book theBook = new Book();

		theModel.addAttribute("book", theBook);
		return "books/book-form";
	}

	@GetMapping("/list")
	public String listBooks(Model theModel) {

		List<Book> theBooks = bookService.findallBook();
		theModel.addAttribute("books", theBooks);
		return "books/list-books";
	}

	@PostMapping("/save")
	public String saveBook(@ModelAttribute("book") Book theBook) {
		bookService.save(theBook);
		return "redirect:/books/list";

	}

	@PostMapping("/delete")
	public String deleteByid(@RequestParam("bookId") int id) {
		bookService.deleteByid(id);
		return "redirect:/books/list";

	}

	@PostMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("bookId") int id, Model theModel) {
		Book book = bookService.findById(id);
		theModel.addAttribute("book", book);
		return "books/book-form";
	}

}
