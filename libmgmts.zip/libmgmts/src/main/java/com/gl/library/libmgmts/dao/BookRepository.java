package com.gl.library.libmgmts.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.gl.library.libmgmts.model.Book;



@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

}
