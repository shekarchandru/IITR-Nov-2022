package com.gl.library.libmgmts.service;

import java.util.List;

import com.gl.library.libmgmts.model.Book;



public interface BookService {
	
	// View the list of Books
	public List<Book> findallBook();
	
	//insert or update book
	public void save(Book theBook);
	
	//delete Book
	public void deleteByid(int id);

	public Book findById(int id);
}
