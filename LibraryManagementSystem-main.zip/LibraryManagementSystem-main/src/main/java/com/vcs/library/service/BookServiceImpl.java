package com.vcs.library.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.vcs.library.entity.Book;

@Service
public class BookServiceImpl implements BookService {

	@Override
	public Book viewBookById(int id) {
		
		return null;
	}

	@Override
	public List<Book> viewAllBooks() {

		return null;
	}

	@Override
	public void insertBook(Book book) {


	}

	@Override
	public void updateBook(Book book) {


	}

	@Override
	public void deleteBookById(int id) {
	

	}

}
