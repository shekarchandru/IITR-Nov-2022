package com.gl.empmgmt.GreatLearningEmpmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GreatLearningEmpmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
