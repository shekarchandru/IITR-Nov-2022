insert into library values (1,'Learn Java, Learn Scala, Learn AWS','Technology library');
insert into library values (2,'Mars Red Planet, Titan with Water','Space Library');
insert into library values (3,'','Animal library');
insert into library values (4,'','Cloud Library');
insert into library values (5,'Yellow Sun, Blue Star, Red Star','star library');
insert into library values (6,'Life of trezi, Life of Brownie','Dogs Library');
insert into library values (7,'XYZ, ABC, EFG','A library');
insert into library values (8,'XYZ, ABC, EFG','B Library');