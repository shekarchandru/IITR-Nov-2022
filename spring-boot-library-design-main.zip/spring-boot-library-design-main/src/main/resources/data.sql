insert into library values(1, 'History', 'Ancient, Medieval, Modern');
insert into library values(2, 'Geography', 'Geomorphology, Oceanography, Physical');
insert into library values(3, 'Mathematics', '3D Geometry, Vectors, Linear Algebra');