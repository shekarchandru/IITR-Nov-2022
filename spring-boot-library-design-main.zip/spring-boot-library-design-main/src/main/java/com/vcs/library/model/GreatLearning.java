package com.vcs.library.model;

import lombok.Data;

@Data
public class GreatLearning {

	private String courseName;
	private String studentName;

}
